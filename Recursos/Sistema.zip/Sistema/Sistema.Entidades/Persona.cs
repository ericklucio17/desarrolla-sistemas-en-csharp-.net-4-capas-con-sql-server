﻿namespace Sistema.Entidades
{
    public class Persona
    {
        public int IdPersona;
        public string TipoPersona;
        public string Nombre;
        public string TipoDocumento;
        public string NumDocumento;
        public string Direccion;
        public string Telefono;
        public string Email;
    }
}
