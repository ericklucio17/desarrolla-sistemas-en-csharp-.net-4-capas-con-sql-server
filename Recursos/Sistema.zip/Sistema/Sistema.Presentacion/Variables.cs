﻿namespace Sistema.Presentacion
{
    public class Variables
    {
        public static int IdUsuario;
        public static int IdProveedor;
        public static string NombreProveedor;
        public static int IdCliente;
        public static string NombreCliente;
        public static int IdVenta;
    }
}
